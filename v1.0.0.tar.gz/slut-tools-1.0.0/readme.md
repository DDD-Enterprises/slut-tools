# 🍆 gangbang — Merge That Leaves You Wrecked™

It’s not a merge. It’s a fucking gangbang. Your directory’s about to take more files than OnlyFans on payday.

gangbang (part of slut-tools) lets you stuff every file you can find into one sticky, code-fenced mess.
With Deep Mode, wildcard pattern matching, filthiness modes, and enough sex jokes to make your sysadmin blush.

## 🚀 Featured Use Cases

- gb docs
  Merge all markdown, text, and doc files into a single cumdump.
- gb fml <pattern>
  Fuzzy/wildcard matching: get every file that *almost* fits.
- gb all, gb gangbang, gb slutify, gb pileup
  Merge everything—no limits, no shame.
- Filthiness Modes:
  tease (PG, innuendo, vanilla), slut (default, filthy AF), freak (NSFW, X-rated, only for the truly depraved).

## 🧰 Installation

Clone, chmod, and let the gangbang begin:

git clone https://github.com/YOUR-USER/slut-tools.git
cd slut-tools
chmod +x gangbang
sudo mv gangbang /usr/local/bin/gb

## 💻 Usage

gb [docs|all|gangbang|slutify|pileup|fml <pattern>] [flags]
gb mode       # interactively pick and save your filth level

| Flag                      | Description                                            |
|---------------------------|--------------------------------------------------------|
| -o, --output <file>       | Where all those loads end up (default: cumdump.md)     |
| -d, --dir <dir>           | Location of the gangbang (default: right here, slut)   |
| -f, --filter <prefix>     | Only let the right kinksters in (prefix filter)        |
| -t, --type <ext>          | What kind of content are you fucking? (default: md)    |
| -n, --name                | Announce every new entry (consent is hot)              |
| -r, --readme              | Let the voyeur watch (include README)                  |
| -l, --log <file>          | Record every position (log file, dirty exhibitionist)  |
| -D, --deep/--no-deep      | Go balls deep (recursive), or keep it shallow          |
| -m, --mode <mode>         | Set filthiness (tease, slut, freak) for this run       |
| -h, --help                | Spank this help menu and beg for more                  |

## 🖤 Examples

gb docs -n -o cumdump.md
gb fml "*202*" --name --output "calendar_bukkake.md"
gb all --no-deep
gb mode          # Select filth level for all future sessions

## 💅 Filthiness Modes

- tease: Cheeky, office-safe, all innuendo.
- slut: (Default) Filthy, clever, brutally honest.
- freak: X-rated, truly offensive, not for church folks.

## 📓 License

MIT License. Free to fuck with.
